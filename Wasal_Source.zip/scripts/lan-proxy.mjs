import http from 'node:http';
const proxy=http.createServer((req,res)=>{
  const upstream=http.request({hostname:'127.0.0.1',port:3000,path:req.url,method:req.method,headers:{...req.headers,host:'127.0.0.1:3000'}},response=>{
    res.writeHead(response.statusCode||502,response.headers);
    response.pipe(res);
  });
  upstream.on('error',()=>{if(!res.headersSent){res.writeHead(502,{'Content-Type':'text/plain; charset=utf-8'});res.end('وصال غير متاح على هذا الجهاز الآن')}else res.destroy()});
  req.pipe(upstream);
});
proxy.listen(3001,'0.0.0.0',()=>console.log('Wasal LAN access on port 3001'));
