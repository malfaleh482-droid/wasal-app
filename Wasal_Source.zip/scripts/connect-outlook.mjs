import { readFile, writeFile } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const envPath=path.join(root,'.env');
try{process.loadEnvFile(envPath)}catch(error){if(error.code!=='ENOENT')throw error}
const clientId=process.env.WASAL_SMTP_OAUTH_CLIENT_ID;
if(!clientId)throw new Error('أضف Application (client) ID إلى WASAL_SMTP_OAUTH_CLIENT_ID في ملف .env أولًا.');
const tenant='consumers',scope='offline_access https://outlook.office.com/SMTP.Send';
const form=values=>new URLSearchParams(values);
const deviceResponse=await fetch(`https://login.microsoftonline.com/${tenant}/oauth2/v2.0/devicecode`,{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:form({client_id:clientId,scope})});
const device=await deviceResponse.json();
if(!deviceResponse.ok)throw new Error(`تعذر بدء تفويض Microsoft: ${device.error_description||device.error||deviceResponse.status}`);
console.log('\nسجّل الدخول بنفس بريد وصال في الصفحة التالية، وأدخل الرمز الظاهر:');
console.log(device.verification_uri);
console.log(`\nرمز التفويض: ${device.user_code}\n`);
let interval=Math.max(Number(device.interval)||5,5),token;
const deadline=Date.now()+Number(device.expires_in||900)*1000;
while(Date.now()<deadline){await new Promise(resolve=>setTimeout(resolve,interval*1000));const response=await fetch(`https://login.microsoftonline.com/${tenant}/oauth2/v2.0/token`,{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:form({grant_type:'urn:ietf:params:oauth:grant-type:device_code',client_id:clientId,device_code:device.device_code})});const result=await response.json();if(response.ok){token=result;break}if(result.error==='authorization_pending')continue;if(result.error==='slow_down'){interval+=5;continue}throw new Error(`تعذر إكمال التفويض: ${result.error_description||result.error}`)}
if(!token?.refresh_token)throw new Error('انتهت مهلة التفويض أو لم يُصدر Microsoft رمز تحديث. أعد المحاولة بعد إكمال الإعداد.');
let env='';try{env=await readFile(envPath,'utf8')}catch(error){if(error.code!=='ENOENT')throw error}
const key='WASAL_SMTP_REFRESH_TOKEN',line=`${key}=${token.refresh_token}`;
if(new RegExp(`^${key}=.*$`,'m').test(env))env=env.replace(new RegExp(`^${key}=.*$`,'m'),line);else env+=`${env.endsWith('\n')||!env?'':'\n'}${line}\n`;
await writeFile(envPath,env,{mode:0o600});
console.log('تم حفظ تفويض Outlook محليًا في .env دون عرض رمز التحديث. أعد تشغيل وصال لتفعيل إرسال الرسائل.');
