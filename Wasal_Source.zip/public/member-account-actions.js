const wireBeforeMemberAccountActions = wirePage;
wirePage = () => {
  wireBeforeMemberAccountActions();
  document.querySelectorAll('[data-member-suspend]').forEach(button => button.addEventListener('click', async () => {
    const reason = prompt(tr('سبب تجميد الحساب:','Reason for freezing this account:'), tr('قرار إداري','Administrative decision'));
    if (reason === null) return;
    if (!confirm(tr('سيُجمّد الحساب ويُسجّل خروج العضو من أجهزته. متابعة؟','This freezes the account and signs the member out of all devices. Continue?'))) return;
    button.disabled = true;
    try {
      await post(`/api/admin/users/${encodeURIComponent(button.dataset.memberSuspend)}/suspend`, { reason });
      toast(tr('تم تجميد الحساب وإنهاء جلساته','Account frozen and sessions ended'));
      await render();
    } catch (error) { toast(error.message); button.disabled = false; }
  }));
  document.querySelectorAll('[data-member-activate]').forEach(button => button.addEventListener('click', async () => {
    if (!confirm(tr('إعادة تفعيل هذا الحساب والسماح له بتسجيل الدخول؟','Reactivate this account and allow it to sign in?'))) return;
    button.disabled = true;
    try {
      await post(`/api/admin/users/${encodeURIComponent(button.dataset.memberActivate)}/activate`);
      toast(tr('تمت إعادة تفعيل الحساب','Account reactivated'));
      await render();
    } catch (error) { toast(error.message); button.disabled = false; }
  }));
  document.querySelectorAll('[data-member-delete]').forEach(button => button.addEventListener('click', async () => {
    if (!confirm(tr('سيُلغى الحساب وتُخفى بياناته ولن يظهر في قوائم أفراد العائلة. لا يمكن التراجع. متابعة؟','This account will be removed from family member lists and its personal details hidden. This cannot be undone. Continue?'))) return;
    button.disabled = true;
    try {
      await api(`/api/admin/users/${encodeURIComponent(button.dataset.memberDelete)}`, { method: 'DELETE' });
      toast(tr('تم حذف الحساب وإخفاء بياناته الشخصية','Account deleted and personal details removed'));
      await render();
    } catch (error) { toast(error.message); button.disabled = false; }
  }));
};

const wireBeforeRoleRemoval = wirePage;
wirePage = () => {
  wireBeforeRoleRemoval();
  document.querySelectorAll('[data-user-role-remove]').forEach(button => button.addEventListener('click', async () => {
    const member = button.closest('.item-row')?.querySelector('.row-main strong')?.textContent || tr('هذا العضو','this member');
    const role = button.closest('.role-chip')?.childNodes[0]?.textContent?.trim() || tr('الدور المحدد','this role');
    if (!confirm(tr(`إزالة دور «${role}» من ${member}؟ ستُسحب صلاحيات الدور فورًا.`,`Remove “${role}” from ${member}? Its permissions will be revoked immediately.`))) return;
    button.disabled = true;
    try {
      await api(`/api/admin/users/${encodeURIComponent(button.dataset.userRoleRemove)}/roles/${encodeURIComponent(button.dataset.roleId)}`, { method: 'DELETE' });
      toast(tr('تمت إزالة الدور وصلاحياته','Role and its permissions removed'));
      await render();
    } catch (error) { toast(error.message); button.disabled = false; }
  }));
};
