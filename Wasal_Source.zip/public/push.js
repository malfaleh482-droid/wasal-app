const baseNotificationsForPush = notifications;
notifications = async () => {
  let html = await baseNotificationsForPush();
  try {
    let localEndpoint='';
    if ('serviceWorker' in navigator) { const registration=await navigator.serviceWorker.getRegistration('/'); const subscription=await registration?.pushManager?.getSubscription(); localEndpoint=subscription?.endpoint||''; }
    const config = await api(`/api/push/config?device=1${localEndpoint?`&endpoint=${encodeURIComponent(localEndpoint)}`:''}`);
    const button = config.subscribed
      ? `<button class="btn btn-light" id="disable-push">${tr('إيقاف إشعارات هذا الجهاز','Turn off notifications on this device')}</button>`
      : `<button class="btn btn-gold" id="enable-push">${tr('تفعيل إشعارات الجوال','Enable phone notifications')}</button>`;
    const card = `<section class="card" style="margin-bottom:16px"><div class="section-head"><div><h2>${tr('تنبيهات الجوال','Phone alerts')}</h2><p class="row-meta">${config.subscribed ? tr('هذا الجهاز يستقبل التنبيهات حتى عند إغلاق وصال.','This device can receive alerts when Wasal is closed.') : tr('اسمح بالإشعارات لتصلك تنبيهات وصال على هذا الجهاز.','Allow notifications to receive Wasal alerts on this device.')}</p></div>${button}</div></section>`;
    html = html.replace('<section class="card"><div class="item-list">', card + '<section class="card"><div class="item-list">');
  } catch {}
  return html;
};

function pushKeyBytes(value) {
  const raw = atob(value.replace(/-/g, '+').replace(/_/g, '/'));
  return Uint8Array.from(raw, char => char.charCodeAt(0));
}

const wireBeforePushControls = wirePage;
wirePage = () => {
  wireBeforePushControls();
  document.querySelector('#enable-push')?.addEventListener('click', async event => {
    const button = event.currentTarget;
    try {
      if (!('serviceWorker' in navigator) || !('PushManager' in window) || !('Notification' in window)) {
        throw new Error(tr('متصفحك لا يدعم إشعارات الويب.','Your browser does not support web push.'));
      }
      const ios = /iPhone|iPad|iPod/.test(navigator.userAgent);
      const installed = navigator.standalone || matchMedia('(display-mode: standalone)').matches;
      if (ios && !installed) throw new Error(tr('على iPhone أضف وصال إلى الشاشة الرئيسية أولًا، ثم افتحه منها وفعّل الإشعارات.','On iPhone, add Wasal to your Home Screen, open it there, then enable notifications.'));
      button.disabled = true;
      if (await Notification.requestPermission() !== 'granted') {
        throw new Error(tr('لم تسمح بالإشعارات. يمكنك تفعيلها من إعدادات المتصفح.','Notifications were not allowed. You can enable them in browser settings.'));
      }
      let localEndpoint='';
    if ('serviceWorker' in navigator) { const registration=await navigator.serviceWorker.getRegistration('/'); const subscription=await registration?.pushManager?.getSubscription(); localEndpoint=subscription?.endpoint||''; }
    const config = await api(`/api/push/config?device=1${localEndpoint?`&endpoint=${encodeURIComponent(localEndpoint)}`:''}`);
      const registration = await navigator.serviceWorker.register('/sw.js', { scope: '/' });
      await navigator.serviceWorker.ready;
      let subscription = await registration.pushManager.getSubscription();
      if (!subscription) subscription = await registration.pushManager.subscribe({ userVisibleOnly: true, applicationServerKey: pushKeyBytes(config.publicKey) });
      const result = await post('/api/push/subscriptions', { subscription: subscription.toJSON() });
      toast(result.catchUpSent ? tr('فُعّلت التنبيهات وأرسلنا التنبيهات غير المقروءة لهذا الجهاز.','Alerts enabled; unread notices were sent to this device.') : tr('تم تفعيل إشعارات هذا الجهاز.','Notifications enabled on this device.'));
      await render();
    } catch (error) { toast(error.message); button.disabled = false; }
  });
  document.querySelector('#disable-push')?.addEventListener('click', async event => {
    const button = event.currentTarget;
    button.disabled = true;
    try {
      const registration = await navigator.serviceWorker.getRegistration('/');
      const subscription = await registration?.pushManager.getSubscription();
      if (subscription) {
        await api('/api/push/subscriptions', { method: 'DELETE', body: JSON.stringify({ endpoint: subscription.endpoint }) });
        await subscription.unsubscribe();
      }
      toast(tr('تم إيقاف إشعارات هذا الجهاز.','Notifications disabled on this device.'));
      await render();
    } catch (error) { toast(error.message); button.disabled = false; }
  });
};

if ('serviceWorker' in navigator) navigator.serviceWorker.register('/sw.js', { scope: '/' }).catch(error => console.warn('Service worker registration failed:', error.message));
