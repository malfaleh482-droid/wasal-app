self.addEventListener('push', event => {
  let message = {};
  try { message = event.data ? event.data.json() : {}; } catch { message = { body: event.data?.text() || '' }; }
  event.waitUntil(self.registration.showNotification(message.title || 'وصال', {
    body: message.body || 'لديك إشعار جديد في وصال.',
    icon: '/assets/wasal-app-icon.png',
    badge: '/assets/wasal-app-icon.png',
    tag: message.tag || 'wasal-notification',
    data: { url: typeof message.url === 'string' && message.url.startsWith('/') ? message.url : '/' },
    dir: 'rtl',
    lang: 'ar'
  }));
});

self.addEventListener('notificationclick', event => {
  event.notification.close();
  const destination = new URL(event.notification.data?.url || '/', self.location.origin).href;
  event.waitUntil(self.clients.matchAll({ type: 'window', includeUncontrolled: true }).then(windows => {
    for (const client of windows) {
      if (new URL(client.url).origin === self.location.origin) return client.focus().then(() => client.navigate(destination));
    }
    return self.clients.openWindow(destination);
  }));
});
